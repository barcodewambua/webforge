# Healthy Squeeze - Natural Health E-commerce Platform

A colorful, user-friendly e-commerce website for "Healthy Squeeze" selling herbal remedies and fresh medicinal juices in Kibera, Nairobi, Kenya.

## Overview

Healthy Squeeze is a community-based e-commerce platform that provides natural, affordable, and healthy alternatives to the local community in Kibera. Our products include traditional herbal remedies and fresh juices made with no preservatives.

## Features

### Product Categories
- **Herbal Remedies**: Traditional pastes like Dawapaste (ginger, tamarind, honey) and Turmeric Healing Paste
- **Fresh Juices**: Natural fruit juices including passion fruit, pineapple, green juice, and moringa superfood juice

### Core Functionality
- Product listing with category filtering
- Detailed product pages with ingredients and medicinal benefits
- Shopping cart with quantity management
- Mock checkout process with payment options (M-Pesa, Cash on Delivery)
- Store locator with geolocation support for Kibera location
- Mobile-responsive design

### Key Features
- **Natural & Organic Design**: Earth-tone color palette reflecting natural ingredients
- **Community Focus**: Highlighting local, affordable branding suitable for Kibera community
- **Health Benefits**: Detailed information about medicinal properties of ingredients
- **Geolocation**: HTML5 Geolocation API for "Find Us" functionality
- **Responsive Design**: Mobile-first approach using Bootstrap 5

## Tech Stack

### Backend
- **Flask**: Python web framework for routing and business logic
- **Flask-Session**: Session management for shopping cart
- **Jinja2**: Template engine for dynamic content rendering

### Frontend
- **HTML5**: Semantic markup with modern web standards
- **CSS3**: Custom styling with CSS Grid and Flexbox
- **Bootstrap 5**: Responsive framework for layout and components
- **JavaScript**: Vanilla JS for interactivity and geolocation
- **Font Awesome**: Icons for enhanced user interface
- **Google Fonts**: Poppins font family for modern typography

### External Services
- **Google Maps**: Embedded map for store location
- **Pixabay Images**: High-quality stock photos for products

## Installation & Setup

### Prerequisites
- Python 3.8 or higher
- pip install package manager

### Step 1: Clone or Create Project Directory
```bash
mkdir healthy-squeeze
cd healthy-squeeze
